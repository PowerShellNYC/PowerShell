﻿## SharePoint Online Document Library Report
Get quick report with a list of all document library in SharePoint Online, including size, files & folder count, etc., to optimize storage.

***Sample Output***

![SharePoint Online document library report](https://o365reports.com/wp-content/uploads/2024/06/SharePoint-document-library-report-Sample-output.png)
## Microsoft 365 Reporting Tool by AdminDroid
Seeking more in-depth reporting? [AdminDroid Microsoft 365 reporting tool](https://admindroid.com/?src=GitHub) provides 1800+ comprehensive reports and 30+ outstanding dashboards to better enhance your Microsoft 365 management effectively.

*View detailed SharePoint document library reports in AdminDroid:*

*<https://demo.admindroid.com/#/1/11/reports/30301/1/20>*