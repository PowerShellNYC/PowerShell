﻿## Microsoft 365: Convert User Mailbox to Shared Mailbox using PowerShell
This PowerShell script helps admins to convert user mailboxes to shared mailboxes.


## Microsoft 365 Reporting tool by AdminDroid
Take your Exchange Online mailbox management to the next level with the [AdminDroid Microsoft 365 Reporting tool](https://admindroid.com/?src=GitHub)! Get access to 1800+ pre-built reports and dashboards for in-depth analysis and efficient oversight.

*Get detailed insights through AdminDroid's comprehensive reports: [https://demo.admindroid.com/#/1/11/reports/10013/1/20](https://demo.admindroid.com/#/1/11/reports/10013/1/20)*

