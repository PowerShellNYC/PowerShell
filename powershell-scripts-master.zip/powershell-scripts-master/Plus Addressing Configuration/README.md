﻿## How to Enable Plus Addressing in Office 365 Exchange online
In Exchange Online, Plus Addressing is not enabled by default. You can enable it using PowerShell. Plus Addressing helps to create dynamic custom email address.
## Microsoft 365 Reporting Tool by AdminDroid
Need more detailed insights? [AdminDroid’s Microsoft 365 reporting tool](https://admindroid.com/?src=GitHub) delivers over 1800 pre-configured reports and dashboards, a perfect complement to your PowerShell scripts.
