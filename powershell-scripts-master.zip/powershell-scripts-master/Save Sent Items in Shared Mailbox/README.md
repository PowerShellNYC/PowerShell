## How to Save Sent Items in Shared Mailbox
Microsoft 365 doesn’t save sent emails in the shared mailbox by default. Admins need to enable settings to save sent items in shared mailbox.
## Microsoft 365 Reporting Tool by AdminDroid
Seeking in-depth analysis? [AdminDroid's Microsoft 365 reporting tool](https://admindroid.com/?src=GitHub) offers an extensive collection of over 1800 ready-made reports and dashboards, perfectly complementing your PowerShell scripts.

*View more comprehensive Shared Mailbox Analytics through AdminDroid: <https://demo.admindroid.com/#/1/11/reports/21001/1/20?easyFilter=%7B%22ExternalAccess%22%3A0%7D>*
